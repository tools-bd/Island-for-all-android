package com.jubayer.islandplus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager

// Fallback: Accessibility on na thakle eta cholbe (Android-er niyome ekta notification lagbei)
class IslandService : Service() {

    private var controller: IslandController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (IslandHost.accessibilityEnabled(this)) {
            stopSelf()
            return
        }
        controller = IslandController(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        if (Settings.canDrawOverlays(this)) controller?.show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Settings.canDrawOverlays(this)) controller?.show()
        return START_STICKY
    }

    override fun onDestroy() {
        controller?.hide()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("island_quiet", "Island", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
        val n = Notification.Builder(this, "island_quiet")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Island")
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}
