package com.jubayer.islandplus

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var preview: View
    private lateinit var picker: ColorPickerView
    private lateinit var hex: EditText
    private lateinit var alphaBar: SeekBar
    private val colorBars = ArrayList<SeekBar>()
    private var syncing = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun curColor() = Color.rgb(
        Prefs.get(this, "cr", 0), Prefs.get(this, "cg", 0), Prefs.get(this, "cb", 0)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF2F2F2F.toInt())
            addView(root)
        })

        button("1. ALLOW DISPLAY OVER OTHER APPS") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. ALLOW NOTIFICATION ACCESS") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. DISABLE BATTERY OPTIMIZATION") {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("4. ACCESSIBILITY (lock screen + no notification)") {
            Toast.makeText(this, "Installed services > Island Plus > ON", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("5. START ISLAND") {
            Prefs.set(this, "enabled", 1)
            if (IslandHost.accessibilityEnabled(this)) {
                IslandHost.modeUpdater?.invoke()
                stopService(Intent(this, IslandService::class.java))
                Toast.makeText(this, "Island on (no notification)", Toast.LENGTH_SHORT).show()
                return@button
            }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Age step 1 ba step 4 koro", Toast.LENGTH_SHORT).show()
                return@button
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(Intent(this, IslandService::class.java))
        }
        button("STOP ISLAND") {
            Prefs.set(this, "enabled", 0)
            IslandHost.modeUpdater?.invoke()
            stopService(Intent(this, IslandService::class.java))
        }
        button("SHADE MODE: island hides behind notification bar (tap to ON/OFF)") {
            val v = 1 - Prefs.get(this, "shade", 1)
            Prefs.set(this, "shade", v)
            IslandHost.modeUpdater?.invoke()
            Toast.makeText(
                this,
                if (v == 1) "ON: notification bar namale island camera-r moto dhuke jabe"
                else "OFF: island shob shomoy upore thakbe",
                Toast.LENGTH_LONG
            ).show()
        }
        button("TEST ISLAND") { IslandHost.notify("Island working ✓") }

        slider("Upor-niche (Y)", "y", 0, 300, 8)
        slider("Bame-dane (X)", "x", -200, 200, 0)
        slider("Chora (Width)", "w", 40, 300, 103)
        slider("Uchota (Height)", "h", 16, 80, 29)

        button("RESET POSITION") {
            Prefs.clearPosition(this)
            IslandHost.refresh()
            recreate()
        }

        // ================= COLOR =================
        heading("ISLAND COLOR")

        preview = View(this)
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        picker = ColorPickerView(this) { c -> setColorAll(c, false) }
        root.addView(
            picker,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
                .apply { topMargin = dp(14) }
        )

        // Hex code
        hex = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF888888.toInt())
            hint = "#RRGGBB"
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                    InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val hexRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hexRow.addView(hex, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hexRow.addView(Button(this).apply {
            text = "APPLY"
            setOnClickListener {
                try {
                    var s = hex.text.toString().trim()
                    if (!s.startsWith("#")) s = "#$s"
                    setColorAll(Color.parseColor(s), true)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Hex thik na (example: #000000)", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(hexRow)

        // Presets (prothom ta PURE BLACK)
        val presets = listOf(
            Color.BLACK, Color.WHITE, 0xFFE53935.toInt(), 0xFF1E88E5.toInt(),
            0xFF43A047.toInt(), 0xFF8E24AA.toInt(), 0xFFFB8C00.toInt(), 0xFFFFD600.toInt()
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { col ->
            val b = Button(this).apply {
                setBackgroundColor(col)
                setOnClickListener { setColorAll(col, true) }
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(8), dp(2), 0) })
        }
        root.addView(row)

        colorBars.add(slider("Red", "cr", 0, 255, 0) { if (!syncing) afterColorChanged(true) })
        colorBars.add(slider("Green", "cg", 0, 255, 0) { if (!syncing) afterColorChanged(true) })
        colorBars.add(slider("Blue", "cb", 0, 255, 0) { if (!syncing) afterColorChanged(true) })
        alphaBar = slider("Opacity %", "ca", 0, 100, 100) { updatePreview() }

        // Text color
        heading("TEXT COLOR")
        val trow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        trow.addView(Button(this).apply {
            text = "AUTO"
            textSize = 11f
            setOnClickListener { Prefs.set(this@MainActivity, "tmode", 0); IslandHost.refresh() }
        }, LinearLayout.LayoutParams(0, dp(44), 1.6f).apply { setMargins(dp(2), 0, dp(2), 0) })
        listOf(
            Color.WHITE, Color.BLACK, 0xFFE53935.toInt(), 0xFF43A047.toInt(),
            0xFF1E88E5.toInt(), 0xFFFFD600.toInt()
        ).forEach { col ->
            trow.addView(Button(this).apply {
                setBackgroundColor(col)
                setOnClickListener {
                    Prefs.set(this@MainActivity, "tmode", 1)
                    Prefs.set(this@MainActivity, "tcol", col)
                    IslandHost.refresh()
                }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        root.addView(trow)

        button("RESET COLOR (pure black)") {
            Prefs.set(this, "tmode", 0)
            alphaBar.progress = 100
            setColorAll(Color.BLACK, true)
        }

        afterColorChanged(true)
    }

    private fun afterColorChanged(updatePicker: Boolean) {
        val c = curColor()
        hex.setText(String.format("#%06X", 0xFFFFFF and c))
        updatePreview()
        if (updatePicker) picker.setColor(c)
    }

    private fun setColorAll(c: Int, updatePicker: Boolean) {
        syncing = true
        Prefs.set(this, "cr", Color.red(c))
        Prefs.set(this, "cg", Color.green(c))
        Prefs.set(this, "cb", Color.blue(c))
        colorBars[0].progress = Color.red(c)
        colorBars[1].progress = Color.green(c)
        colorBars[2].progress = Color.blue(c)
        syncing = false
        IslandHost.refresh()
        afterColorChanged(updatePicker)
    }

    private fun updatePreview() {
        val a = Prefs.get(this, "ca", 100).coerceIn(0, 100) * 255 / 100
        val c = curColor()
        preview.background = GradientDrawable().apply {
            setColor(Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), 0xFF888888.toInt())
        }
    }

    private fun heading(t: String) {
        root.addView(TextView(this).apply {
            text = t
            setTextColor(0xFF80CBC4.toInt())
            textSize = 18f
            setPadding(0, dp(28), 0, dp(8))
        })
    }

    private fun button(label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }
        root.addView(
            b,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(8) }
        )
    }

    private fun slider(
        label: String, key: String, lo: Int, hi: Int, def: Int,
        onChange: (() -> Unit)? = null
    ): SeekBar {
        val title = TextView(this).apply {
            setTextColor(0xFFDDDDDD.toInt())
            textSize = 16f
            setPadding(0, dp(16), 0, 0)
        }
        val start = Prefs.get(this, key, def)
        title.text = "$label: $start"
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = start - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                title.text = "$label: $v"
                Prefs.set(this@MainActivity, key, v)
                IslandHost.refresh()
                onChange?.invoke()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(title)
        root.addView(bar)
        return bar
    }
}
