package com.jubayer.islandplus

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Accessibility on thakle system nijei island chalu kore, notification lage na
        if (Prefs.get(context, "enabled", 0) == 1 && !IslandHost.accessibilityEnabled(context)) {
            try {
                context.startForegroundService(Intent(context, IslandService::class.java))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
