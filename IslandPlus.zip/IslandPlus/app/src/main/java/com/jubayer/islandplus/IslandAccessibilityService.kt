package com.jubayer.islandplus

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Notification dewa service dorkar nei, system nijei cholay.
 *
 * - Unlock obosthay: TYPE_APPLICATION_OVERLAY -> notification bar nambale island tar NICHE chole jay (camera-r bhitore dhuke jaoar moto)
 * - Lock screen e: TYPE_ACCESSIBILITY_OVERLAY -> lock screen er upore-o dekha jay
 */
class IslandAccessibilityService : AccessibilityService() {

    private var appCtrl: IslandController? = null
    private var accCtrl: IslandController? = null
    private var locked = false
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> locked = true
                Intent.ACTION_USER_PRESENT -> locked = false
                Intent.ACTION_SCREEN_ON -> {
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    locked = km.isKeyguardLocked
                }
            }
            updateMode()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        appCtrl = IslandController(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        accCtrl = IslandController(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        // Notification dewa service dorkar nei, bondho kore dao
        stopService(Intent(this, IslandService::class.java))

        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        locked = km.isKeyguardLocked

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        receiverRegistered = true

        IslandHost.modeUpdater = { updateMode() }
        updateMode()
    }

    private fun updateMode() {
        val a = appCtrl ?: return
        val b = accCtrl ?: return
        if (Prefs.get(this, "enabled", 1) != 1) {
            a.hide(); b.hide()
            return
        }
        val shadeHide = Prefs.get(this, "shade", 1) == 1
        val canApp = Settings.canDrawOverlays(this)
        if (shadeHide && canApp && !locked) {
            b.hide()
            a.show()
        } else {
            a.hide()
            b.show()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (e: Exception) { }
        }
        appCtrl?.hide()
        accCtrl?.hide()
        IslandHost.modeUpdater = null
        super.onDestroy()
    }
}
