package com.jubayer.islandplus

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View

// Shob rong baachar jonno: upore Saturation/Brightness box, niche Hue bar
class ColorPickerView(ctx: Context, private val onPick: (Int) -> Unit) : View(ctx) {

    private val hsv = floatArrayOf(0f, 0f, 0f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val svRect = RectF()
    private val hueRect = RectF()
    private var mode = 0
    private val d = resources.displayMetrics.density
    private val radius = 10 * d

    fun setColor(c: Int) {
        Color.colorToHSV(c, hsv)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val hueH = 28 * d
        val gap = 12 * d
        svRect.set(0f, 0f, w.toFloat(), h - hueH - gap)
        hueRect.set(0f, h - hueH, w.toFloat(), h.toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        val hueColor = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            svRect.left, 0f, svRect.right, 0f, Color.WHITE, hueColor, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(svRect, radius, radius, paint)
        paint.shader = LinearGradient(
            0f, svRect.top, 0f, svRect.bottom, Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(svRect, radius, radius, paint)

        val hues = IntArray(7) { Color.HSVToColor(floatArrayOf((it * 60f) % 360f, 1f, 1f)) }
        paint.shader = LinearGradient(
            hueRect.left, 0f, hueRect.right, 0f, hues, null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(hueRect, radius, radius, paint)
        paint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * d
        paint.color = Color.WHITE
        val cx = hsv[1] * svRect.width()
        val cy = (1f - hsv[2]) * svRect.height()
        canvas.drawCircle(cx, cy, 9 * d, paint)
        val hx = hsv[0] / 360f * hueRect.width()
        canvas.drawRoundRect(
            hx - 4 * d, hueRect.top - 2 * d, hx + 4 * d, hueRect.bottom + 2 * d, 4 * d, 4 * d, paint
        )
        paint.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = if (e.y <= svRect.bottom + 6 * d) 1 else 2
                parent?.requestDisallowInterceptTouchEvent(true)
                update(e)
            }
            MotionEvent.ACTION_MOVE -> update(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    private fun update(e: MotionEvent) {
        if (svRect.width() <= 0f) return
        if (mode == 1) {
            hsv[1] = (e.x / svRect.width()).coerceIn(0f, 1f)
            hsv[2] = 1f - (e.y / svRect.height()).coerceIn(0f, 1f)
        } else {
            hsv[0] = (e.x / hueRect.width()).coerceIn(0f, 1f) * 359.99f
        }
        invalidate()
        onPick(Color.HSVToColor(hsv))
    }
}
